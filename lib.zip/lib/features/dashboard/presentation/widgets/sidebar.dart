import 'package:flutter/material.dart';

class Sidebar extends StatelessWidget {
  const Sidebar({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFF263238),
      child: ListView(
        children: const [
          SizedBox(height: 20),
          ListTile(
            leading: Icon(Icons.dashboard, color: Colors.white),
            title: Text(
              'Dashboard',
              style: TextStyle(color: Colors.white),
            ),
          ),
          ListTile(
            leading: Icon(Icons.shopping_cart, color: Colors.white),
            title: Text(
              'Sales',
              style: TextStyle(color: Colors.white),
            ),
          ),
          ListTile(
            leading: Icon(Icons.inventory_2, color: Colors.white),
            title: Text(
              'Inventory',
              style: TextStyle(color: Colors.white),
            ),
          ),
          ListTile(
            leading: Icon(Icons.factory, color: Colors.white),
            title: Text(
              'Production',
              style: TextStyle(color: Colors.white),
            ),
          ),
          ListTile(
            leading: Icon(Icons.people, color: Colors.white),
            title: Text(
              'HR',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}