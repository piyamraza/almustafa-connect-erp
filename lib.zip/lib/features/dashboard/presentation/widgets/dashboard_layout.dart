import 'package:flutter/material.dart';

import '../../../../core/constants/app_colors.dart';
import 'cards/dashboard_stat_card.dart';
import 'sidebar.dart';

class DashboardLayout extends StatelessWidget {
  const DashboardLayout({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        title: const Text(
          'Almustafa Connect ERP',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: Row(
        children: [
          const SizedBox(
            width: 250,
            child: Sidebar(),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Dashboard",
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 20),

                  GridView.count(
                    crossAxisCount: 4,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    mainAxisSpacing: 20,
                    crossAxisSpacing: 20,
                    childAspectRatio: 2.2,
                    children: const [
                      DashboardStatCard(
                        title: "Today's Sales",
                        value: "Rs. 0",
                        icon: Icons.attach_money,
                        color: Colors.green,
                      ),
                      DashboardStatCard(
                        title: "Orders",
                        value: "0",
                        icon: Icons.shopping_cart,
                        color: Colors.blue,
                      ),
                      DashboardStatCard(
                        title: "Inventory",
                        value: "0",
                        icon: Icons.inventory_2,
                        color: Colors.orange,
                      ),
                      DashboardStatCard(
                        title: "Customers",
                        value: "0",
                        icon: Icons.people,
                        color: Colors.purple,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}